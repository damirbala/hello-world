<?php

	$connection = mysql_connect("localhost","root","");
	// mysql_connect('host','user_name','password');

	if($connection){

		mysql_select_db("bloggeek");		

	}	

?>