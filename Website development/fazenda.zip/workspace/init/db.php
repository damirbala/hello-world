<?php

	$connection = mysql_connect("localhost","diboss","");
	

	if($connection){

		mysql_select_db("fazenda");	
		//$connection->set_charset("utf8");

	}	

?>