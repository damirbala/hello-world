<?php
    
 
    
       
    session_start();
    
    include 'init/db.php';

    $page = "profile";
    $user = array();

    $online = false;


	if(isset($_SESSION['user_id'])){

		$online = true;

	}else if(isset($_SESSION['imp_id'])){
	    
	    $online = true;
	}

$e = "";


    


    

if($online){

    if(isset($_GET['act'])){
        
        if($_GET['act']=='logout'){
            
            if(isset($_SESSION['user_id'])){
            unset($_SESSION['user_id']);
            }else if(isset($_SESSION['imp_id'])){
                unset($_SESSION['imp_id']);
            }
            header("Location:?page=main");
            
        }
        else if($_GET['act']=='send_task'){
            
            $encode_query = mysql_query("SET NAMES UTF8");
            
             $names = isset($_POST['names']) ? $_POST['names'] : '';
             
            $task = $_POST['task'];
            
            
     
            foreach($names as $n) {
            if($task!=''){
                
                   
                   $task = mysql_real_escape_string($task);
                   
                   $date = date("Y-m-d");
                   
                   $sql_query = "INSERT INTO task VALUES (
                       NULL,
                       \"".$task."\",
                       '',
                       '',
                       0,
                       \"".$date."\",
                       '',
                       0,
                       ".$n."
                       )";
                       
                       mysql_query($sql_query);
               
               
               
            }
        }
        
         header("Location:?page=cheftask");
     
         
        } else if($_GET['act']=='up_task_passed'){
            
             $encode_query = mysql_query("SET NAMES UTF8");
             
            $eid = $_POST['task_id'];
            //$task_pass = $_POST['task_passed'];
            $task_give = $_POST['task_gived'];
            $task_how = $_POST['howmuch'];
            $task_what = $_POST['what'];
            
            $task_pass = $task_how." ".$task_what;
           
            
            $date = date("Y-m-d");
            
            $query = mysql_query("UPDATE task
                SET task_passed = \"".$task_pass."\" ,end_date = \"".$date."\" WHERE eid = ".$eid." AND task_gived = \"".$task_give."\" ");
                
                header("Location:?page=employeepage");
        }
        else if($_GET['act']=="Access"){
            
            
             $encode_query = mysql_query("SET NAMES UTF8");
             
            $id = $_POST['eid'];
            $taskg = $_POST['taskG'];
            $state = 1;
        
  
            $query = mysql_query("UPDATE task SET state = ".$state."  WHERE eid = ".$id." AND task_gived = \"".$taskg."\" ");
            
            header("Location:?page=chefresultgo&id=".$id);
            
        }
        else if($_GET['act']=='Deny'){
            
             $encode_query = mysql_query("SET NAMES UTF8");
             
             $id = $_POST['eid'];
            $taskg = $_POST['taskG'];
            $state = 0;
       
            $query = mysql_query("UPDATE task SET task_passed = '-' WHERE eid = ".$id." AND task_gived = \"".$taskg."\" ");
            
            header("Location:?page=chefresultgo&id=".$id);
            
        }
        else if($_GET['act']=='setPrice'){
            
             $encode_query = mysql_query("SET NAMES UTF8");
             
            $eid = $_POST['eid'];
            $taskG = $_POST['taskG'];
            $money = $_POST['takemoney'];
            
            $query = mysql_query("UPDATE task SET price = ".$money." WHERE task_gived = \"".$taskG."\" AND eid = ".$eid." ");
            header("Location:?page=accountantpage&names1=".$eid);
        }
        else if($_GET['act']=='add_employee'){
            
            
            
            $name = $_POST['employee_fname'];
            $surname = $_POST['employee_lname'];
            $password = $_POST['employee_password'];
            $age = $_POST['employee_age'];
            $phone = $_POST['employee_phone'];
            $address = $_POST['employee_address'];
            $city = $_POST['employee_city'];
            $gender = $_POST['employee_gender'];
            $worktype = $_POST['employee_title'];
            
              mysql_query("SET NAMES utf8;");
              
            $job_query = "SELECT id FROM job WHERE job_title = \"".$worktype."\"";
            
            $jresult = mysql_query($job_query) or die(mysql_error());
            
            
            
            if(mysql_num_rows($jresult)>0){
                
                
                $query_for_duplicate = mysql_query("SELECT name, password FROM employees WHERE name = \"".$name."\"  AND password = \"".$password."\" ");
              
                if(mysql_num_rows($query_for_duplicate)){
                    
                    header("Location:?page=addemployee&fail=1");
                }else{
                $job = mysql_fetch_array($jresult);
               
            
         
                
            $sql_query = mysql_query("INSERT INTO employees (id,name,surname,password,age,city,gender,address,phone,jid,self,state) VALUES (NULL, \"".$name."\", \"".$surname."\", \"".$password."\" , \"".$age."\", \"".$city."\", \"".$gender."\",\"".$address."\",\"".$phone."\",\"".$job['id']."\", 0,'hired')");
            
            
            
            
              header("Location:?page=addemployee");
            
            }
            }
              
        }
        else if($_GET['act']=='delete_employee') {
            
             $encode_query = mysql_query("SET NAMES UTF8");
             
             $i = isset($_POST['emp_id']) ? $_POST['emp_id'] : '';
             
        
            
    if (!empty($i))
	{
		
		foreach ($i as $a)
		{
			    
			    $query_for_delete = "UPDATE employees SET state = 'fired' WHERE id = ".$a."  ";
			 
			 
                mysql_query($query_for_delete);
                    
		}
		
         header("Location:?page=deleteemployee");
        }
            
           
        }
        else if($_GET['act']=='writecom'){
            
             $encode_query = mysql_query("SET NAMES UTF8");
            
            $id = $_POST['id'];
            $com = $_POST['comment1'];
            $today = date("Y-m-d");
            if($com!=''){
                
             $sql_query = "INSERT INTO comments(id,comment,com_date,eid) VALUES (
                       NULL,
                       \"".$com."\",
                       \"".$today."\",
                 
                       ".$id."
                       )";
                       
                       mysql_query($sql_query);
               
            
            header("Location:?page=lookdate&id=".$id);
               
        
               
            }
            
        }
    
        
        	
	
    }
    
    if(isset($_SESSION['user_id'])){

        mysql_query("SET NAMES utf8");
        
		$query = mysql_query("SELECT * FROM employees WHERE id = ".$_SESSION['user_id']." ");

			if(mysql_num_rows($query)>0){

				$user = mysql_fetch_array($query);

			}
		
		}
		
		else if(isset($_SESSION['imp_id'])){
		    
		     mysql_query("SET NAMES utf8");
		     
		     	$query = mysql_query("SELECT * FROM important WHERE id = ".$_SESSION['imp_id']." ");
			    	
			if(mysql_num_rows($query)>0){

				$im_user = mysql_fetch_array($query);

			}
		    
		}
        
        if(isset($_GET['page'])){
            
            if($_GET['page']=='accounting'){
                $page = "accounting";
            }
            else if($_GET['page']=='addemployee'){
                $page = "addemployee";
            }
            else if($_GET['page']=='adminpage'){
                $page = "adminpage";
            }
            else if($_GET['page']=='attendance'){
                $page = "attendance";
            }
            else if($_GET['page']=='chefresult'){
                $page = "chefresult";
            }
            else if($_GET['page']=='cheftask'){
                $page = "cheftask";
            }
            else if($_GET['page']=='deleteemployee'){
                $page = "deleteemployee";
            }
            else if($_GET['page']=='employee'){
                $page = "employee";
            }
            else if($_GET['page']=='employeepage'){
                $page = "employeepage";
            }
            else if($_GET['page']=='profile'){
                $page = "profile";
            }
            else if($_GET['page']=='accountantpage'){
                $page = "accountantpage";
            }
            else if($_GET['page']=='lookdate'){
                $page = "lookdate";
            }
            else if($_GET['page']=='comment'){
                $page = "comment";
            } 
            else if($_GET['page']=='accepted'){
                $page = "accepted";
            }
            else if($_GET['page']=='cheftaskgo'){
                $page = "cheftaskgo";
            }
            else if($_GET['page']=='chefresultgo'){
                $page = "chefresultgo";
            }
            else{				

				$page = "404";

			}
        }else {
            
            $page = "profile";
        }
}else{
    
    if(isset($_GET['act'])){
        
        if($_GET['act']=='auth'){
        
         mysql_query("SET NAMES utf8;");
         
            $login = $_POST['login'];
            $password = $_POST['password'];
            
            if($login!="" && $password!=""){
                
            
                 
                $emp_query = mysql_query("SELECT * FROM employees WHERE name = \"".$login."\" AND password = \"".$password."\" AND state = 'hired' ");
                
                if(mysql_num_rows($emp_query)>0){
                    
                  
                    $user = mysql_fetch_array($emp_query);
                    
                    if($user['self']==0){
                        
                        header("Location:?page=changepass&empid=".$user['id']);
                    }else{
                    $_SESSION['user_id'] = $user['id'];
                    header("Location:?page=employeepage");
                    }
                }else {
                    
                    $imp_query = mysql_query("SELECT * FROM important WHERE login = \"".$login."\" AND password = \"".$password."\" ");
                    
                    if(mysql_num_rows($imp_query)>0){
                        
                        
                        if($login=='admin'){
                             $im_user = mysql_fetch_array($imp_query);
                        $_SESSION['imp_id'] = $im_user['id'];
                        header("Location:?page=adminpage");
                        }
                        else if($login=='accountant'){
                             $im_user = mysql_fetch_array($imp_query);
                        $_SESSION['imp_id'] = $im_user['id'];
                            header("Location:?page=accountantpage");
                        }else if($login=='chef'){
                             $im_user = mysql_fetch_array($imp_query);
                        $_SESSION['imp_id'] = $im_user['id'];
                            header("Location:?page=cheftask");
                        }
                    }else{
                        
                        header("Location:?page=main&err=3");
                    }
                }
            }
        }
        else if($_GET['act']=='register'){
        
          
            $name = $_POST['fname'];
            $surname = $_POST['lname'];
            $password = $_POST['password'];
            $age = $_POST['age'];
            $phone = $_POST['phonenumber'];
            $address = $_POST['address'];
            $city = $_POST['city'];
            $gender = $_POST['gender'];
            $worktype = $_POST['worktype'];
            
              mysql_query("SET NAMES utf8;");
              
            $job_query = "SELECT id FROM job WHERE job_title = \"".$worktype."\"";
            
            $jresult = mysql_query($job_query) or die(mysql_error());
            
            
            
            if(mysql_num_rows($jresult)>0){
                
                $job = mysql_fetch_array($jresult);
               echo "yes";
            }
            else {
                
             
                echo "why??";
            }
                
            $sql_query = mysql_query("INSERT INTO employees (id,name,surname,password,age,city,gender,address,phone,jid,self,state) VALUES (NULL, \"".$name."\", \"".$surname."\", \"".$password."\" , \"".$age."\", \"".$city."\", \"".$gender."\",\"".$address."\",\"".$phone."\",\"".$job['id']."\",1,'hired')");
            
            
            
            
                header("Location:?page=main");
            
            
        }
        else if($_GET['act']=='changepass'){
            
           
            $new = $_POST['newpass'];
            $renew = $_POST['renewpass'];
            $id = $_POST['id'];
            
            if($new==$renew){
                
                 $query = mysql_query("UPDATE employees
                SET password = \"".$new."\" ,self = 1  WHERE id = ".$id."  ");
                
                header("Location:?page=main");
            }else {
                header("Location:?page=changepass&empid=".$id."&fail=2");
                
            }
        }
      
    }
    
    if(isset($_GET['page'])){

			$page = 'main';

			if($_GET['page']=='regpage'){

				$page = 'regpage';

			}else if($_GET['page']=='main'){

				$page = 'main';

			}
			else if($_GET['page']=='changepass'){
			    
			    $page = 'changepass';
			    
			}
			else {
			    
			    $page = '404';
			}

		}else{

			$page = 'main';

		}

}
    



  include "pages/".($online?"logged/":"notlogged/").$page.".php";


?>









