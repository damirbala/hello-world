<!DOCTYPE html>
<html style="background: url(images/bg.jpg) center no-repeat;  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
  height:100%;"
>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/login.css">
	<title>Панель админа - Вход</title>
</head>
<body style="">

	<div class="container"> 
		<div class="col-md-offset-4 col-md-4 col-sm-12">
			<div class="text-center fazenda-logo">
				<a href="#"><img src="images/newlogo.png"></a>
			</div>
			<div class="text-center login-title">
				<p>Лучший в своем деле</p>
			</div>
			
			<?php
				
				if(isset($_GET['err'])){
					
					if($_GET['err']=='3') {
						$e = "Неправильные данные";	
					}
						else {
							
							$e =  "Упс";
						}
				}
				
			?>
			<form id="login-form" class="form-horizontal" action="?act=auth" method="post">
				<input type="hidden" name="login">
				<div class="form-group field-loginform-username required">
					<div class='col-md-12'>
						<label class="control-label">Логин</label>
						<input type="text"  class="form-control" name="login">
						<div class="help-block">	
						</div>
					</div>
				</div>
				<div class="form-group field-loginform-password required">
					<div class='col-md-12'>
					<label class="control-label">Пароль</label>
					<input type="password" class="form-control" name="password">
					<br>
					<span style = "color: red;"><?php echo $e;?></span>
						<div class = "help-block">
						</div>
						</div>
					</div>

				<div class="form-group">
					<div class="col-md-12">
						<input type="submit" class="btn btn-primary login-button" name="login-button" value = "Войти">
				    
                            <a href="?page=regpage" style="float:right;">Регистрация</a>
					</div>
				</div>
				
				

			</form>
        
        </div>
			
			
		</div>
		<div class="login-footer">
			Фазенда 2016
		</div>
<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


	</body>
	</html>