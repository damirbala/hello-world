<!DOCTYPE html>
<html style="background: url(images/login-bg.jpg); -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/login.css">
	<title>Панель админа - Регистрация</title>
</head>
<body>

	<div class="container">
   
<div class="col-md-offset-4 col-md-4 col-sm-12">
            <div class="text-center fazenda-logo">
                <a href="#"><img src="images/login-logo.png"></a>
            </div>
            <div class="text-center fazenda-reg">
            Регистрация
            </div>
            <form id="login-form" class="form-horizontal" action="?act=register" method="post">
                        
                        <label >Имя</label>
                        <input type="text" class="form-control" name="fname" placeholder="Введите имя">
                        <br>
                        <label >Фамилия</label>
                        <input type="text"  class="form-control" name="lname" placeholder="Введите фамилию">
                        <br>
                        <label >Пароль</label>
                        <input type="password" class="form-control" name="password" placeholder="Введите пароль">
                        <br>
                        <label >Возраст</label>
                        <input type="text" class="form-control" name="age" placeholder="Введите Ваш возраст">
                        <br>
                        <label>Номер телефона</label>
                        <input type="text" name="phonenumber" class="form-control" placeholder="Введите номер телефона">    
                        <br>
                        <label>Адрес проживания</label>
                        <input type="text" name="address" class="form-control" placeholder="Введите адрес">
                        <br>
                        <label  class="m-t-10">Выберите город</label>
                        <select id="states" class="form-control" name="city">
                            <option value="Алматы">Алматы</option>
                            <option value="Астана">Астана</option>
                        </select>
                        
                        <br>
                        <label  class="m-t-10">Ваш пол</label>
                        <select  class="form-control unselected" name="gender">
                            <option value="Женский">Женский</option>
                            <option value="Мужской">Мужской</option>
                        </select>
                        
                        <br>
                        <label  class="m-t-10">Выберите специализацию</label>
                        <select  class="form-control unselected" name="worktype">
                            <option value="Садовник">Садовник</option>
                            <option value="Доярка">Доярка</option>
                            <option value="Повар">Повар</option>
                            <option value="Котник">Котник</option>
                            <option value="Электрик">Электрик</option>                    
                            <option value="Охранник">Охранник</option>
                            <option value="Водитель">Водитель</option>
                        </select>
                        <br>    
                         <center><input type="submit" class="btn btn-primary m-t-10"  name="send" value="Подтвердить"></center>
                         <br>
                         <center></center><a href="?page=main" style="text-align: center;">К главной странице</a></center>
        </form>
        </div>
        </div>
		<div class="login-footer">
			Фазенда 2016
		</div>

<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	</body>
	</html>
