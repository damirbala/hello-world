<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<title>Фазенда - Должность #</title></head>
	<body>
	<style type="text/css">
		  						.responstable {
  margin: 1em 0;
  width: 100%;
  overflow: hidden;
  background: #FFF;
  color: #024457;
  border-radius: 10px;
  border: 1px solid #167F92;
}
.responstable tr {
  border: 1px solid #D9E4E6;
}
.responstable tr:nth-child(odd) {
  background-color: #EAF3F3;
}
.responstable th {
  display: none;
  border: 1px solid #FFF;
  background-color: #2c3742;
  color: #FFF;
  padding: 1em;
}
.responstable th:first-child {
  display: table-cell;
  text-align: center;
}
.responstable th:nth-child(2) {
  display: table-cell;
}
.responstable th:nth-child(2) span {
  display: none;
}
.responstable th:nth-child(2):after {
  content: attr(data-th);
}
@media (min-width: 480px) {
  .responstable th:nth-child(2) span {
    display: block;
  }
  .responstable th:nth-child(2):after {
    display: none;
  }
}
.responstable td {
  display: block;
  word-wrap: break-word;
  max-width: 7em;
}
.responstable td:first-child {
  display: table-cell;
  text-align: center;
  border-right: 1px solid #D9E4E6;
}
@media (min-width: 480px) {
  .responstable td {
    border: 1px solid #D9E4E6;
  }
}
.responstable th, .responstable td {
  text-align: left;
  margin: .5em 1em;
}
@media (min-width: 480px) {
  .responstable th, .responstable td {
    display: table-cell;
    padding: 1em;
  }
}

		  					</style>


		<div class="container">
			<div class="row">


				<div class="header">
					<div class="container">
						<div class="row">
							<div class="col-md-5">
								<div class="logo">
									<img src="images/fazenda_white.png" style="margin-top:2%;margin-left:15%;width:30%;height:30%;"></img>
								</div>
							</div>
							<div class="col-md-5">
								<div class="row">
									<div class="col-lg-12">
									</div>
								</div>
							</div>
							<div class="col-md-7">
								<div class="navbar navbar-inverse" role="banner">
									<nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
										<ul class="nav navbar-nav">
											<li class="dropdown">
												 <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php 
	                        mysql_query("set names utf8");
	                        echo $im_user['name'] . " " . $im_user['surname'];
	                        ?></a>

											</li>
										</ul>
									</nav>
								</div>
							</div>
						</div>
					</div>



				</div>
			</div>

			<div class="page-content">
				<div class="row">
					<div class="col-lg-3">
						<div class="sidebar content-box" style="display: block;">
							<ul class="nav">
								<li class="current"><a href=""><i class="glyphicon glyphicon-home"></i>Задачи</a></li>
								<li><a href="?page=chefresult"><i class="glyphicon glyphicon-stats"></i>Результаты</a></li>
								<li><a href="?page=profile"><i class="glyphicon glyphicon-user"></i>Профиль</a></li>
								<li><a href="?act=logout">Выйти</a></li>
							</ul>
						</div>
					</div>




					<div class="row">
						<div class="col-lg-12">
							<div class="content-box-large">
								<div class="panel-heading">
									<div class="panel-title" style="font-size: 20px;">Панель выдачи задач</div>
								</div>
								
								<div class="panel-body">
									<label style="color:#888;">Выберите должность  :</label>
								<form action="?" method = "get">
									<input type="hidden" value="cheftask" name = "page">
									<select class="jobtitle" name = "jobtype">
										
										<?php
											
											$query = mysql_query("select job_title from job");
											
											if(mysql_num_rows($query)>0){
												
												while($row = mysql_fetch_array($query)) {
																if($_GET['jobtype']==$row['job_title']){	
													?>
												
														<option value="<?php echo $row['job_title'];?>" selected = "selected"><?php echo $row['job_title'];?></option>
													
													<?php
												}else {
													
													?>
													
														<option value="<?php echo $row['job_title'];?>"><?php echo $row['job_title'];?></option>
													
													
													<?php
												}
												}
											}
										?>
									
									
									</select>
								<button class="btn btn-success btn-md" style="margin-left:50px;">Выбрать</button>
								</form>
									<br><br><br>
									<label style="color:#888;">Выберите имя и фамилию работника  :</label>
							<form action = "?" method = "get">
								<input type = "hidden" value = "cheftaskgo" name = "page">
						
										
											<table class="responstable">
				              <thead>
				                <tr>
				                  <th><i class="glyphicon glyphicon-ok"></i></th>
				              
				                  <th>Имя</th>
				                  <th>Фамилия</th>
				                  <th>Город</th>
				                  <th>Должность</th>
				                 
				                </tr>
				              </thead>
				              
				              
				              
				              
													
				              <?php
				            	if(isset($_GET['jobtype'])){
										
										mysql_query("SET NAMES utf8");
											$jobtype = $_GET['jobtype'];
											$job_query = mysql_query("SELECT id FROM job WHERE job_title = \"".$jobtype."\" ");
											if(mysql_num_rows($job_query)>0){
												
												$job = mysql_fetch_array($job_query);
											
												$name_sur_query = mysql_query("SELECT id, name, surname, city, jid FROM employees WHERE jid = \"".$job['id']."\" AND state = 'hired' ");
												
												if(mysql_num_rows($name_sur_query)>0) {
													
													while($empls = mysql_fetch_array($name_sur_query)){
				            			?>
				            			
				            			 <tbody>
				                <tr>
				                	<td><input type = "checkbox" name = "empl_id[]" value = "<?php  echo $empls['id'];?>"></td>
				             
				                  <td><?php  echo $empls['name'];?></td>
				                  <td><?php  echo $empls['surname'];?></td>
				                  <td><?php  echo $empls['city'];?></td>
				                
				                  <td><?php  
				                  
				                  $query1 = mysql_query("SELECT job_title FROM job WHERE id = ".$empls['jid']." ");
				                  
				                  if(mysql_num_rows($query1)>0){
				                  	$j = mysql_fetch_array($query1);
				                  	
				                  
				                  echo $j['job_title'];
				                  	
				                  }
				                  
				                  ?></td>
				                
				                </tr>
					              </tbody>
					              
				            			<?php
				            			
				            		}
				            	}
											}
				            	}
				            		
				            	
				              ?>
				             
					            

				            </table>
										<button class="btn btn-success btn-md" style="margin-left:50px;">Выбрать</button>
										
						
										<br>
										<br>
							</form>	
								</div>

							</div>
						</div>
					</div>



<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

				</body>
				</html>