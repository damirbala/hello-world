<!DOCTYPE html>
<html>
<head>
	
	<?php
	 mysql_query("SET NAMES utf8");
	?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<title>Фазенда - Должность #</title></head>
<body>
	<style type="text/css">
												<style type="text/css">
		  						.responstable {
  margin: 1em 0;
  width: 100%;
  overflow: hidden;
  background: #FFF;
  color: #024457;
  border-radius: 10px;
  border: 1px solid #167F92;
}
.responstable tr {
  border: 1px solid #D9E4E6;
}
.responstable tr:nth-child(odd) {
  background-color: #EAF3F3;
}
.responstable th {
  display: none;
  border: 1px solid #FFF;
  background-color: #2c3742;
  color: #FFF;
  padding: 1em;
}
.responstable th:first-child {
  display: table-cell;
  text-align: center;
}
.responstable th:nth-child(2) {
  display: table-cell;
}
.responstable th:nth-child(2) span {
  display: none;
}
.responstable th:nth-child(2):after {
  content: attr(data-th);
}
@media (min-width: 480px) {
  .responstable th:nth-child(2) span {
    display: block;
  }
  .responstable th:nth-child(2):after {
    display: none;
  }
}
.responstable td {
  display: block;
  word-wrap: break-word;
  max-width: 7em;
}
.responstable td:first-child {
  display: table-cell;
  text-align: center;
  border-right: 1px solid #D9E4E6;
}
@media (min-width: 480px) {
  .responstable td {
    border: 1px solid #D9E4E6;
  }
}
.responstable th, .responstable td {
  text-align: left;
  margin: .5em 1em;
}
@media (min-width: 480px) {
  .responstable th, .responstable td {
    display: table-cell;
    padding: 1em;
  }
}

		  					</style>

<div class="container">
	<div class="row">


	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <div class="logo">
					<img src="images/fazenda_white.png" style="margin-top:2%;margin-left:15%;width:30%;height:30%;"></img>
	              </div>
	            
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">
	                </div>
	              </div>
	           </div>
	            <div class="col-md-7">
	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                       
	                        </li>
	                        </ul>
	                        </nav>
	                        </div>
	        </div>
	     </div>
	</div>

	

	</div>
</div>

<div class="page-content">
    	<div class="row">
		  <div class="col-lg-3">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <li><i class="glyphicon glyphicon-user"></i>  <?php 
                    
                     
                      
                      echo $user['name']; ?></li>
                    <li><i class="glyphicon glyphicon-font"></i>  <?php echo $user['surname'];?></li>
                    <li><i class="glyphicon glyphicon-cog"></i>   <?php
                  
                    $query = mysql_query("SELECT job_title FROM job WHERE id = \"".$user['jid']."\" ");
                    if(mysql_num_rows($query)>0)
                    {
                    	$title = mysql_fetch_array($query);
                    	echo $title['job_title'];
                    }
                    ?></li>
                    <li><i class="glyphicon glyphicon-pushpin"></i>  <?php 
                  
                    echo $user['city'];?></li>
                    <li><i class="glyphicon glyphicon-align-justify"></i>  <?php echo $user['age'];?></li>
                    <li><i class="glyphicon glyphicon-home"></i>  <?php echo $user['address'];?></li>
                    <li><i class="glyphicon glyphicon-earphone"></i>   <?php echo $user['phone'];?></li>
                    <li><i class="glyphicon glyphicon-usd"></i>   <?php 
                    
                    $query = mysql_query("SELECT price FROM task WHERE eid = ".$user['id']." ");
                    if(mysql_num_rows($query)>0){
                    	
                    	
                    	while($price = mysql_fetch_array($query)){
                    		
                    		$akwa += $price['price'];
                    	}
                  
                    	
                    
                    echo $akwa." тг.";
                    }else {
                    	echo "0 тг.";
                    }?></li>
                    <li><a href = "?page=accepted" style = "color:green;">Сделанные задания</a></li>
                    <li>  <a href = "?page=comment">Комментарий</a></li>
                    <li><a href="?act=logout">Выйти</a></li>
                </ul>
             </div>
		  </div>



		  <div class="row">
			<div class="col-lg-12">
  					<div class="content-box-large">
		  				<div class="panel-heading">
							<div class="panel-title">Панель задач</div>
							
						
						</div>

		  				<div class="panel-body">
		  				
		  					
            				<?php  
            					
            					$query_for_task = mysql_query("SELECT task_gived, task_passed FROM task WHERE eid = \"".$user['id']."\" AND state = 0");
            					
            					if(mysql_num_rows($query_for_task)>0){
            						
            						?>
            						
            						<form action="?act=up_task_passed" method = "post">
            							<?php
            						
            						while($task_gived = mysql_fetch_array($query_for_task)){
            						
            						if($task_gived['task_passed']==""){
            						?>
            							
            									
            									 <input type = "hidden" value = "<?php echo $user['id'];?>" name = "task_id">
          										 <input type = "hidden" value = "<?php echo $task_gived['task_gived'];?>" name = "task_gived">
            									<table class="table table-bordered">
            									<thead>
		  							
		  							<tr>
		  								<th>Состояние</th>
		  								<th>Дано задача</th>
		  								<th>Сколько</th>
		  								<th>Что</th>
		  							</tr>
		  						</thead>
				 		
            								<tbody>
            									
            									<tr>
            										<td>Сделайте работу</td>
            										<td><?php echo $task_gived['task_gived'];?></td>
            										<td><input type = "text" name = "howmuch"></td>
            										<td><input type = "text" name = "what"></td>
            										
            									</tr>
            								</tbody>
            										
        
            				
            				</table>			
            							
            							
            							
					                 <div class="panel-footer" style="height:60px;">
				            
				            
				            	<button class="btn btn-success btn-md" style="float:right;margin-bottom:35px;">Отправить</button>
				            </div>	
            					
				         
            			
  				
  				

<?php
}else if($task_gived['task_passed']=='-'){
	?>	
            							
            							
            									 <input type = "hidden" value = "<?php echo $user['id'];?>" name = "task_id">
          										 <input type = "hidden" value = "<?php echo $task_gived['task_gived'];?>" name = "task_gived">
            									<table class="table table-bordered">
            									<thead>
		  							
		  							<tr>
		  								<th>Состояние</th>
		  								<th>Дано задача</th>
		  								<th>Сколько</th>
		  								<th>Что</th>
		  							</tr>
		  						</thead>
            							<tbody>
            								
            								<tr>
            									<td style = "color: red;">Переделайте работу</td>
            									<td><?php echo $task_gived['task_gived'];?></td>
            									<td><input type = "text" name = "howmuch"></td>
            									<td><input type = "text" name = "what"></td>
            									
            								</tr>
            							</tbody>
            						
    
        	
        	
        	</table>
        	
        	 <div class="panel-footer">
				            
				            
				            	<button class="btn btn-success btn-md" style="float:right;margin-bottom:35px;">Отправить</button>
				            </div>	


<?php
}

/*
else if($task_gived['task_passed']!="" && $task_gived['task_passed']!="-"){
	?>
	
			 <div class="content-box-large">
            							<label class="task_label">
            								
            								<?php
	echo $task_gived['task_gived'];
	echo "	в ожидании";
	echo "<br>";
	echo "<br>";
	
	?>
	
	</label>
	</div>
	
	 
	<?php
}*/
}
?>

	</form>
    	<?php
}else {
	?>
	<div class="panel-options task_panel">
            							<label class="task_label">
            								<?php
	echo "Ожидайте задания!";
	
	?>
	
	</label>
	</div>
	<?php
}
?>
</table>
</div>
</div>
</div>
</div>



<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	
	
	</body>
	</html>