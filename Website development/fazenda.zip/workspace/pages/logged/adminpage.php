<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<title>Фазенда - панель админа</title></head>
<body>



<div class="container">
	<div class="row">


	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <div class="logo">
	              		<img src="images/fazenda_white.png" style="margin-top:2%;margin-left:15%;width:30%;height:30%;"></img>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">
	                </div>
	              </div>
	           </div>
	            <div class="col-md-7">
	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                        <a href="?page=profile" class="dropdown-toggle" data-toggle="dropdown">
	                        	<?php
	                        	
	                        	$pagetitle = mysql_query("SELECT name,surname FROM important WHERE jobtitle = 'Админ' ");
	                        	
	                        	echo $pagetitle['name'] . " " . $pagetitle['surname'];
	                        	
	                        	?>
	                     	</a>
	                        </li>
	                        </ul>
	                        </nav>
	                        </div>
	        </div>
	     </div>
	</div>

	

	</div>
</div>

<div class="page-content">
    	<div class="row">
		  <div class="col-lg-3">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <li class="current"><a href=""><i class="glyphicon glyphicon-home"></i>Главная</a></li>
                    <li><a href="?page=employee"><i class="glyphicon glyphicon-stats"></i>Работники</a></li>
                    <li><a href="?page=attendance"><i class="glyphicon glyphicon-record"></i>Посещаемость</a></li>
                    <li><a href="?page=accounting"><i class="glyphicon glyphicon-pencil"></i>Бухгалтерия</a></li>
                    <li><a href="?page=profile"><i class="glyphicon glyphicon-user"></i>Профиль</a></li>
                    <li><a href="?act=logout">Выйти</a></li>
                </ul>
             </div>
		  </div>



		  <div class="row">
			
				<div class="col-md-3" style="border:2px solid #184252;border-radius:11px;height:85px;width:20%;margin-top:1%;margin-left:1%;" >
				<a href="?page=employee" style="text-decoration:none;font-size:160%;color:#184252;"><center>100</center>
					
					<center>работников</center></a>
				</div>
				<div class="col-md-3" style="border:2px solid #184252;border-radius:11px;height:85px;width:20%;margin-top:1%;margin-left:1%;" >
				<a href="?page=employee" style="text-decoration:none;font-size:160%;color:#184252;"><center>100</center>
					
					<center>работников</center></a>
				</div>
				<div class="col-md-3" style="border:2px solid #184252;border-radius:11px;height:85px;width:20%;margin-top:1%;margin-left:1%;" >
				<a href="?page=employee" style="text-decoration:none;font-size:160%;color:#184252;"><center>100</center>
					
					<center>работников</center></a>
				</div>
				<div class="col-md-3" style="border:2px solid #184252;border-radius:11px;height:85px;width:20%;margin-top:1%;margin-left:1%;" >
				<a href="?page=employee" style="text-decoration:none;font-size:160%;color:#184252;"><center>100</center>
					
					<center>работников</center></a>
				</div>
				<div class="col-md-3" style="border:2px solid #184252;border-radius:11px;height:85px;width:20%;margin-top:1%;margin-left:1%;" >
				<a href="?page=employee" style="text-decoration:none;font-size:160%;color:#184252;"><center>100</center>
					
					<center>работников</center></a>
				</div>
				<div class="col-md-3" style="border:2px solid #184252;border-radius:11px;height:85px;width:20%;margin-top:1%;margin-left:1%;" >
				<a href="?page=employee" style="text-decoration:none;font-size:160%;color:#184252;"><center>100</center>
					
					<center>работников</center></a>
				</div>
				
  				
  				</div>




<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	</body>
	</html>