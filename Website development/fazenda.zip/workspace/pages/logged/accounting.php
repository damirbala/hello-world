<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<title>Фазенда - панель админа
	</title></head>
<body>



<div class="container">
	<div class="row">


	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <div class="logo">
					<img src="images/fazenda_white.png" style="margin-top:2%;margin-left:15%;width:30%;height:30%;"></img>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">
	                </div>
	              </div>
	           </div>
	            <div class="col-md-7">
	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                         <a href="#" class="dropdown-toggle" data-toggle="dropdown"></a>
	                        </li>
	                        </ul>
	                        </nav>
	                        </div>
	        </div>
	     </div>
	</div>

	

	</div>
</div>

<div class="page-content">
    	<div class="row">
		  <div class="col-lg-3">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <li><a href="?page=adminpage"><i class="glyphicon glyphicon-home"></i>Главная</a></li>
                    <li><a href="?page=employee"><i class="glyphicon glyphicon-stats"></i>Работники</a></li>
                    <li><a href="?page=attendance"><i class="glyphicon glyphicon-record"></i>Посещаемость</a></li>
                    <li class="current"><a href=""><i class="glyphicon glyphicon-pencil"></i>Бухгалтерия</a></li>
                    <li><a href="?page=profile"><i class="glyphicon glyphicon-user"></i>Профиль</a></li>
                    <li><a href="?act=logout">Выйти</a></li>
                </ul>
             </div>
		  </div>





		  <div class="row">
  				<div class="col-md-12">
  					<div class="content-box-large">
		  				<div class="panel-heading">
							<div class="panel-title">Таблица работников</div>
		
							<div class="help-block">
						</div>
						</div>
		  				<div class="panel-body">
		  						<label style="color:#888;">Сортировать по должностям  :</label>
									<select class="jobtitle" style="">
										<option value="Садовник">Садовник</option>
										<option value="Доярка">Доярка</option>
										<option value="Повар">Повар</option>
										<option value="Котник">Котник</option>
										<option value="Электрик">Электрик</option>                    
										<option value="Охранник">Охранник</option>
										<option value="Водитель">Водитель</option>
										</select>
										<label style="color:#888;">Сортировать по ФИ   :</label>
										<select class="jobtitle">
											<option value="Садовник">Имя фамилия</option>
											<option value="Садовник">Имя фамилия</option>
											<option value="Садовник">Имя фамилия</option>
											<option value="Садовник">Имя фамилия</option>
											<option value="Садовник">Имя фамилия</option>
										</select>
										<style type="text/css">
												<style type="text/css">
		  						.responstable {
  margin: 1em 0;
  width: 100%;
  overflow: hidden;
  background: #FFF;
  color: #024457;
  border-radius: 10px;
  border: 1px solid #167F92;
}
.responstable tr {
  border: 1px solid #D9E4E6;
}
.responstable tr:nth-child(odd) {
  background-color: #EAF3F3;
}
.responstable th {
  display: none;
  border: 1px solid #FFF;
  background-color: #2c3742;
  color: #FFF;
  padding: 1em;
}
.responstable th:first-child {
  display: table-cell;
  text-align: center;
}
.responstable th:nth-child(2) {
  display: table-cell;
}
.responstable th:nth-child(2) span {
  display: none;
}
.responstable th:nth-child(2):after {
  content: attr(data-th);
}
@media (min-width: 480px) {
  .responstable th:nth-child(2) span {
    display: block;
  }
  .responstable th:nth-child(2):after {
    display: none;
  }
}
.responstable td {
  display: block;
  word-wrap: break-word;
  max-width: 7em;
}
.responstable td:first-child {
  display: table-cell;
  text-align: center;
  border-right: 1px solid #D9E4E6;
}
@media (min-width: 480px) {
  .responstable td {
    border: 1px solid #D9E4E6;
  }
}
.responstable th, .responstable td {
  text-align: left;
  margin: .5em 1em;
}
@media (min-width: 480px) {
  .responstable th, .responstable td {
    display: table-cell;
    padding: 1em;
  }
}

		  					</style>
									
									
									<?php
									
										if(isset($_GET['id']) && isset($_GET['date'])){
											
											$eid = $_GET['id'];
											$pdate = $_GET['date'];
											
											$query = mysql_query("SELECT e.name, e.surname, j.job_title, t.task_gived, t.task_passed, t.percentage, t.price, t.date FROM (employees e INNER JOIN job j ON e.jid = j.id) INNER JOIN task t ON e.id = t.eid WHERE e.id = ".$eid." AND date BETWEEN \"".$pdate."\"  AND \"".date("Y-m-d")."\" ");
									
									
										}
									?>
		  					<table class="responstable">
				              <thead>
				                <tr>
				            
				                  <th>Имя</th>
				                  <th>Фамилия</th>
				                  <th>Должность</th>
				                  <th>Посещаемость</th>
				                  <th>Дано задача</th>
				                  <th>Выполнение задачи</th>
				                  <th>Дата</th>
				                  <th>В процентах(%)</th>
				                  <th>Итог дня</th>
				                </tr>
				              </thead>
				              
				              <?php
				              
				              	if(mysql_num_rows($query)>0){
				              		
				              		while($row = mysql_fetch_array($query)){
				              			
				              			?>
				              			
				              			<tbody>
				                <tr>
				                 
				                  <td><?php echo $row['name'];?></td>
				                  <td><?php echo $row['surname'];?></td>
				                  <td><?php echo $row['job_title'];?></td>
				                  <td><?php 
				                  $query2 = mysql_query("SELECT end_date FROM task WHERE eid = ".$eid);
				                  
				                  if(mysql_num_rows($query2)>0){
				                  $s = "";
				                  	while($t = mysql_fetch_array($query2)){
				                  	
				                		if(date("Y-m-d")==$t['end_date']){
				                		$s = "Был";
				                		break;
				                		}
				                  	
				                  }
				                  
				                  if($s=="Был"){
				                  	echo "Был";
				                  }else{
				                  	echo "Не был";
				                 }
				                  }
				                  ?></td>
				                  <td><?php echo $row['task_gived'];?></td>
				                  <td><?php echo $row['task_passed'];?></td>
				                  <td><?php echo $row['date'];?></td>
				                  
				                  <td><?php echo $row['percentage'];?></td>
				                  <td><?php echo $row['price'];?><b>.тг</b></td>
				                </tr>
					              </tbody>
				              			
				              			<?php
				              		}
				              	}
				              ?>
				              
					             


							
							
				            </table>
				            	<button class="btn btn-success btn-md" style="float:right;margin-top:10px;">Сохранить</button>
		  				</div>
		  			</div>
  				</div>




<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	</body>
	</html>