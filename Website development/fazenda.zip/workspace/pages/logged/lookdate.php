<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<title>Фазенда - панель админа</title></head>
	
	<script>
	    
	     function say_day(day) {

        
            
             alert(day + "!!!");
             
            


	</script>
<body>



<div class="container">

	<div class="row">


	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <div class="logo">
                        <img src="images/fazenda_white.png" style="margin-top:2%;margin-left:15%;width:30%;height:30%;"></img>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">
	                </div>
	              </div>
	           </div>
	            <div class="col-md-7">
	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                        <a href="?page=profile" class="dropdown-toggle" data-toggle="dropdown">
	                        <?php 
	                        mysql_query("set names utf8");
	                        echo $user['name'] . " " . $user['surname'];
	                        ?>
	                        </a>
	                        </li>
	                        </ul>
	                        </nav>
	                        </div>
	                        
	        </div>
	     </div>
	</div>

	

	</div>
</div>

    <?php
	
	if(isset($_GET['id'])){
		
		$eid = $_GET['id'];
	}
?>

<div class="page-content">
    	<div class="row">
		  <div class="col-md-3">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <li><a href="?page=adminpage"><i class="glyphicon glyphicon-home"></i>Главная</a></li>
                    <li><a href="?page=employee"><i class="glyphicon glyphicon-stats"></i>Работники</a></li>
                    <li><a href="?page=attendance"><i class="glyphicon glyphicon-record"></i>Посещаемость</a></li>
                    <li><a href="?page=accounting"><i class="glyphicon glyphicon-pencil"></i>Бухгалтерия</a></li>
                    <li><a href="?page=profile"><i class="glyphicon glyphicon-user"></i>Профиль</a></li>
                    <li><a href="?act=logout">Выйти</a></li>
                </ul>
             </div>
		  </div>



		  <div class="row">
  				<div class="col-lg-8">
  					<div class="content-box-large">
		  				<div class="panel-heading">
						
							
						
						</div>
		  				<div class="panel-body">
		  				<?php 

$cday = "";

function draw_calendar($month,$year,$eid1){
  /* Начало таблицы */
  $calendar = '<table cellpadding="0" cellspacing="0" class="calendar">';
  /* Заглавия в таблице */
  $headings = array('Понедельник','Вторник','Среда','Четверг','Пятница','Субота','Воскресенье');
  $calendar.= '<tr class="calendar-row"><td class="calendar-day-head">'.implode('</td><td class="calendar-day-head">',$headings).'</td></tr>';
  /* необходимые переменные дней и недель... */
  $running_day = date('w',mktime(0,0,0,$month,1,$year));
  $running_day = $running_day - 1;
  $days_in_month = date('t',mktime(0,0,0,$month,1,$year));
  $days_in_this_week = 1;
  $day_counter = 0;
  $dates_array = array();
  /* первая строка календаря */
  $calendar.= '<tr class="calendar-row">';
  /* вывод пустых ячеек в сетке календаря */
  for($x = 0; $x < $running_day; $x++):
    $calendar.= '<td class="calendar-day-np"> </td>';
    $days_in_this_week++;
  endfor;
  /* дошли до чисел, будем их писать в первую строку */
  
  for($list_day = 1; $list_day <= $days_in_month; $list_day++):
      
      $datee = $year."-".$month."-".$list_day;
      
    $calendar.= '<td class="calendar-day"><a href = "?page=accounting&id='.$eid1.'&date='.$datee.'"><div class = "calendar-day">';
      /* Пишем номер в ячейку */
      $calendar.= '<div class="day-number">'.$list_day.'</div>';
      /** ЗДЕСЬ МОЖНО СДЕЛАТЬ MySQL ЗАПРОС К БАЗЕ ДАННЫХ! ЕСЛИ НАЙДЕНО СОВПАДЕНИЕ ДАТЫ СОБЫТИЯ С ТЕКУЩЕЙ - ВЫВОДИМ! **/
      
      
     
      $calendar.= str_repeat('<p> </p>',2);
    
      //echo "<h3>".$datee."</h3>";
    $calendar.= '</div></a></td>';
    if($running_day == 6):
      $calendar.= '</tr>';
      if(($day_counter+1) != $days_in_month):
        $calendar.= '<tr class="calendar-row">';
      endif;
      $running_day = -1;
      $days_in_this_week = 0;
    endif;
    $days_in_this_week++; $running_day++; $day_counter++;
  endfor;
  

  /* Выводим пустые ячейки в конце последней недели */
  if($days_in_this_week < 8):
    for($x = 1; $x <= (8 - $days_in_this_week); $x++):
      $calendar.= '<td class="calendar-day-np"> </td>';
    endfor;
  endif;
  /* Закрываем последнюю строку */
  $calendar.= '</tr>';
  /* Закрываем таблицу */
  $calendar.= '</table>';
  
  /* Все сделано, возвращаем результат */
  return $calendar;
}
/* СПОСОБ ПРИМЕНЕНИЯ */

?>


		
										
<form action = "?" method = "get">
    	<input type="hidden" value="lookdate" name = "page">
<select name = "year">
    
    <?php
        
        $year = 2016;

        $nextyear = intval(date("Y")+3);
    
        $diff = $nextyear - $year;
          
         $year_num = 2016;
         $i=0;
         while($i<=$diff){
           
            if($_GET['year'] == $year_num){
           ?>
           
            <option value = "<?php echo $year_num;?>" selected = "selected"><?php  echo  $year_num;?></option>
            
           <?php
             
        
         }
         else {
             
             ?>
               <option value = "<?php echo $year_num;?>"><?php  echo  $year_num;?></option>
             
             <?php
         }
         
              $year_num++;
             $i++;
         }
      
    ?>

    
</select>

<select name = "month">
    <?php
    
        $array = array(
                "12" => "Декабрь",
                "01" => "Январь",
                "02" => "Февраль",
                "03" => "Март",
                "04" => "Апрель",
                "05" => "Май",
                "06" => "Июнь",
                "07" => "Июль",
                "08" => "Август",
                "09" => "Сентябрь",
                "10" => "Октябрь",
                "11" => "Ноябрь",
                
            );
            
            foreach ($array as $i => $value) {
          
                if($_GET['month'] == $i){
            ?>
            
                    <option value = "<?php echo $i;?>" selected = "selected"><?php echo $array[$i];?></option>
                    
            <?php    
            }else {
                
                ?>
                
                 <option value = "<?php echo $i;?>"><?php echo $array[$i];?></option>
                 
                <?php
            }
            }
    ?>

    
    
</select>

<input type = "hidden" name = "id1" value = "<?php echo $eid;?>">
<input type = "submit" value = "Далее">

</form>

<?php


        if(isset($_GET['year']) || isset($_GET['month']) && isset($_GET['id1'])){
        $year1 = $_GET['year'];
         $month1 = $_GET['month'];
        $eid1 = $_GET['id1'];
      
        echo '<h2>'.$month1." ".$year1.'</h2>';

        echo draw_calendar(intval($month1),intval($year1),$eid1);
        
        }



?>

<br>
<br>



<form action="?act=writecom" method = "post">
	<div class="form-group">
								
									<label for="comment" style="color:#888;font-size: 19px;margin-left: 0px;">Комментарий</label>

									<input type = "hidden" name = "id" value = "<?php echo $eid;?>">
									<textarea class="form-control" rows="5" id="comment" name = "comment1"></textarea>
									</div>
										
										<button class="btn btn-success btn-lg" style="float:right;">Отправить</button>
										</form>
		  				</div>
		  			</div>
  				</div>


<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</body>
	</html>