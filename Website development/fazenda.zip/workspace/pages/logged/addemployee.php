<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<title>Фазенда - панель админа</title></head>
<body>



<div class="container">
	<div class="row">



				<div class="header">
					<div class="container">
						<div class="row">
							<div class="col-md-5">
								<div class="logo">
                  <img src="images/fazenda_white.png" style="margin-top:2%;margin-left:15%;width:30%;height:30%;"></img>
								</div>
							</div>
							<div class="col-md-5">
								<div class="row">
									<div class="col-lg-12">
									</div>
								</div>
							</div>
							<div class="col-md-7">
								<div class="navbar navbar-inverse" role="banner">
									<nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
										<ul class="nav navbar-nav">
											<li class="dropdown">
											   <a href="#" class="dropdown-toggle" data-toggle="dropdown"></a>

											</li>
										</ul>
									</nav>
								</div>
							</div>
						</div>
					</div>



				</div>
</div>

<div class="page-content">
    	<div class="row">
		  <div class="col-md-3">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <li><a href="?page=adminpage"><i class="glyphicon glyphicon-home"></i>Главная</a></li>
                    <li class="current"><a href="?page=employee"><i class="glyphicon glyphicon-stats"></i>Работники</a></li>
                    <li><a href="?page=attendance"><i class="glyphicon glyphicon-record"></i>Посещаемость</a></li>
                    <li><a href="?page=accounting"><i class="glyphicon glyphicon-pencil"></i>Бухгалтерия</a></li>
                    <li><a href="?page=profile"><i class="glyphicon glyphicon-user"></i>Профиль</a></li>
                    <li><a href="?act=logout">Выйти</a></li>
                </ul>
             </div>
		  </div>




  				<div class="col-md-12">
  					<div class="content-box-large">
		  				<div class="panel-body" style="width:100%;">
		  					<table class="table table-bordered">
				            
					           
					           <form class="form-vertical"  method="post" action="?act=add_employee"> 
 
	
    						 <legend>Форма для добавления работников</legend> 

							<?php
							  if(isset($_GET['fail'])){
							    
							    if($_GET['fail']=='1'){
							      
							      echo "Придумайте другой пароль!";
							    }
							  }
							?>
							
							<div class="form-group">
							     
                          <label class="col-md-2 control-label labelforemployee">Имя</label> 
                          <div class="col-md-4"> 
                            <input  name="employee_fname" type="text" placeholder="Введите имя" class="form-control input-sm fam"> 
                            <div class="help-block"></div>
                          </div> 
                        </div> 
                     
                        
                        	<div class="form-group"> 
                          <label class="col-md-1 control-label labelforemployee">Фамилия</label> 
                          <div class="col-md-4"> 
                            <input  name="employee_lname" type="text" placeholder="Введите фамилию" class="form-control input-sm fam"> 
                            <div class="help-block"></div>
                          </div> 
                        </div>
                        

                        	<div class="form-group"> 
                          <label class="col-md-2 control-label labelforemployee">Возраст</label> 
                          <div class="col-md-4"> 
                            <input  name="employee_age" type="text" placeholder="Введите возраст" class="form-control input-sm fam">
                            <div class="help-block"></div>
                          </div> 
                        </div>
                        

                        	<div class="form-group"> 
                          <label class="col-md-1 control-label labelforemployee">Город</label> 
                          <div class="col-md-4"> 
                            <input  name="employee_city" type="text" placeholder="Введите город" class="form-control input-sm fam"> 
                            <div class="help-block"></div>
                          </div> 
                        </div> 
                        
                        
                        
                        	<div class="form-group"> 
                          <label class="col-md-2 control-label labelforemployee">Адрес</label> 
                          <div class="col-md-4"> 
                            <input  name="employee_address" type="text" placeholder="Введите адрес" class="form-control input-sm fam"> 
                            <div class="help-block"></div>
                          </div> 
                        </div> 
                        
                        
                        
                        	<div class="form-group"> 
                          <label class="col-md-1 control-label labelforemployee">Телефон</label> 
                          <div class="col-md-4"> 
                            <input  name="employee_phone" type="text" placeholder="Введите номер телефона" class="form-control input-sm fam"> 
                            <div class="help-block"></div>
                          </div> 
                        </div> 	
                        
                        
                        
                        <div class="form-group"> 
                          <label class="col-md-2 control-label labelforemployee">Пол</label> 
                          <div class="col-md-4"> 
								 <select name="employee_gender" class="form-control"> 
                    				<option value="Мужской" selected="selected">Мужской</option> 
                    				<option value="Женский">Женский</option> 
                  				</select>
                  				<div class="help-block"></div>
                          </div> 
                        </div> 
                        
                       
                        
                        	<div class="form-group"> 
                          <label class="col-md-1 control-label labelforemployee">Должность</label> 
                          <div class="col-md-4"> 
                          <select name="employee_title" class="form-control">
                          <option value="Садовник">Садовник</option>
                            <option value="Доярка">Доярка</option>
                            <option value="Повар">Повар</option>
                            <option value="Котник">Котник</option>
                            <option value="Электрик">Электрик</option>                    
                            <option value="Охранник">Охранник</option>
                            <option value="Водитель">Водитель</option>
                            </select>
                            <div class="help-block"></div>
                          </div> 
                        </div> 	
				           
				                	<div class="form-groKup"> 
                          <label class="col-md-2 control-label labelforemployee">Пароль</label> 
                          <div class="col-md-4"> 
                            <input  name="employee_password" type="text" placeholder="Введите пароль работника" class="form-control input-sm fam"> 
                            <div class="help-block"><br></div>
                          </div> 
                        </div> 	
				            
				            
				            <div class="panel-options">
								 <button class="btn btn-success btn-lg add_employee">Добавить работника</button>
								<br>
							</div>
							</form>
							</form>
							</table>
							<br>
							<br>
		  					
		  				</div>
		  			</div>
  				</div>




<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	</body>
	</html>