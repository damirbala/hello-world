   
   <?php
    
    if(isset($_GET['empl_id'])){
        
        $empls = $_GET['empl_id'];
        
         foreach($empls as $e){
 ?>
 	<input type = "hidden" name = "names[]" value = "<?php echo $e;?>">
 	
 <?php
    }
    
    }
    
    
  
   ?>
   
   
   

		
		
		
		
		
		
		<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<title>Фазенда - Должность #</title></head>
	<body>



		<div class="container">
			<div class="row">


				<div class="header">
					<div class="container">
						<div class="row">
							<div class="col-md-5">
								<div class="logo">
									<img src="images/fazenda_white.png" style="margin-top:2%;margin-left:15%;width:30%;height:60%;"></img>
								</div>
							</div>
							<div class="col-md-5">
								<div class="row">
									<div class="col-lg-12">
									</div>
								</div>
							</div>
							<div class="col-md-7">
								<div class="navbar navbar-inverse" role="banner">
									<nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
										<ul class="nav navbar-nav">
											<li class="dropdown">
												 <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php 
	                        mysql_query("set names utf8");
	                        echo $im_user['name'] . " " . $im_user['surname'];
	                        ?></a>

											</li>
										</ul>
									</nav>
								</div>
							</div>
						</div>
					</div>



				</div>
			</div>

			<div class="page-content">
				<div class="row">
					<div class="col-lg-3">
						<div class="sidebar content-box" style="display: block;">
							<ul class="nav">
								<li><a href="?page=cheftask"><i class="glyphicon glyphicon-home"></i>Задачи</a></li>
								<li><a href="?page=chefresult"><i class="glyphicon glyphicon-stats"></i>Результаты</a></li>
								<li><a href="?page=profile"><i class="glyphicon glyphicon-user"></i>Профиль</a></li>
								<li><a href="?act=logout">Выйти</a></li>
							</ul>
						</div>
					</div>




					<div class="row">
						<div class="col-lg-12">
							<div class="content-box-large">
							
								    <form action = "?act=send_task" method = "post">
	    <div class="form-group" style="height:25%;">
	     
									<label for="comment" style="color:#888;font-size: 19px;margin-left: 0px;">Суть задачи</label>

									<textarea class="form-control" rows="5" id="comment" name = "task"></textarea>
								
										
										<button class="btn btn-success btn-md" style="float:right;margin-top:2%;">Отправить</button>
											</div>
								</form>	 
								
		
		
		
		
							
							</div>
						</div>
					</div>




<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

				</body>
				</html>