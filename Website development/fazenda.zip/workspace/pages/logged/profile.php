<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<title>Панель админа - Администратор</title></head>
<body>



<div class="container">
	<div class="row">


				<div class="header">
					<div class="container">
						<div class="row">
							<div class="col-md-5">
								<div class="logo">
                                    <img src="images/fazenda_white.png" style="margin-top:2%;margin-left:15%;width:30%;height:30%;"></img>
								</div>
							</div>
							<div class="col-md-5">
								<div class="row">
									<div class="col-lg-12">
									</div>
								</div>
							</div>
							<div class="col-md-7">          
								<div class="navbar navbar-inverse" role="banner">
									<nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
										<ul class="nav navbar-nav">
											<li class="dropdown">

											</li>
										</ul>
									</nav>
								</div>
							</div>
						</div>
					</div>



				</div>
</div>

<div class="page-content">
    	<div class="row">
		  <div class="col-md-3">
		  	<div class="sidebar content-box" style="display: block;">
		  		<?php
            		
            					mysql_query("SET NAMES utf8");
            					
            					$query_profile = mysql_query("SELECT * FROM important WHERE id = \"".$im_user['id']."\" ");
            					
            		
            					
            					if(mysql_num_rows($query_profile)>0){
            						
            						$rows = mysql_fetch_array($query_profile);
            						
            						if($rows['jobtitle']=='Админ'){
            						?>
            						
                <ul class="nav">
                    <li><a href="?page=adminpage"><i class="glyphicon glyphicon-home"></i>Главная</a></li>
                    <li><a href="?page=employee"><i class="glyphicon glyphicon-stats"></i>Работники</a></li>
                    <li><a href="?page=attendance"><i class="glyphicon glyphicon-record"></i>Посещаемость</a></li>
                    <li><a href="?page=accounting"><i class="glyphicon glyphicon-pencil"></i>Бухгалтерия</a></li>
                    <li class="current"><a href=""><i class="glyphicon glyphicon-user"></i>Профиль</a></li>
                    <li><a href="?act=logout">Выйти</a></li>
                </ul>
                <?php
                }else if($rows['jobtitle']=='Бухгалтер'){
                	?>
                	 <ul class="nav">
                    <li><a href="?page=accountantpage"><i class="glyphicon glyphicon-home"></i>Бухгалтерия</a></li>
                    <li class="current"><a href=""><i class="glyphicon glyphicon-user"></i>Профиль</a></li>
                    <li><a href="?act=logout">Выйти</a></li>
                </ul>
                	<?php
                	
                }else if($rows['name']=='Начальник'){
                	
                	?>
                		<ul class="nav">
								<li><a href="?page=cheftask"><i class="glyphicon glyphicon-home"></i>Задачи</a></li>
								<li><a href="?page=chefresult"><i class="glyphicon glyphicon-stats"></i>Результаты</a></li>
								<li class="current"><a href=""><i class="glyphicon glyphicon-user"></i>Профиль</a></li>
								<li><a href="?act=logout">Выйти</a></li>
							</ul>
                	<?php
                }
                
                ?>
             </div>
		  </div>



		  <div class="row">
  				<div class="col-md-6">
							<div class="container">
      <div class="row">
        <div class="col-xs-11 col-sm-11 col-md-1 col-lg-6 col-xs-offset-0 col-sm-offset-1 col-md-offset-2 col-lg-offset-1 toppad profileblock" >
   
   
          <div class="panel panel-info" style="border-color:#2c3742;">
            <div class="panel-heading" style="background-color:#2c3742;border-color:#2c3742;">
              <h3 class="panel-title" style="padding-top:20px;">
              	<?php 
            						echo $rows['name'] . " " . $rows['surname'];
            					}
            					?></h3>
            </div>
            <div class="panel-body">
                
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>Должность : </td>
                        <td><?php echo $rows['jobtitle'];?></td>
                      </tr>
                      <tr>
                        <td>Возраст : </td>
                        <td> <?php echo $rows['age'];?></td>
                      </tr>
                        <td>Пол : </td>
                        <td><?php echo $rows['gender'];?></td>
                      </tr>
                        <tr>
                        <td>Адрес : </td>
                        <td><?php echo $rows['address'];?></td>
                      </tr>
                        <td>Телефон : </td>
                        <td><?php echo $rows['phone'];?></td>
                        </td>
                           
                      </tr>
                     
                    </tbody>
                  </table>
                  

            
          </div>
        </div>
      </div>
    </div>
							
		  				</div>
		  			</div>
  				</div>
		
		 </div>

	</div>
	</div>


<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	</body>
	</html>