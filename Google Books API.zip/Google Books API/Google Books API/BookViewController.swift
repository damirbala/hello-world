//
//  BookViewController.swift
//  Google Books API
//
//  Created by User on 10/10/16.
//  Copyright © 2016 User. All rights reserved.
//

import UIKit

class BookViewController: UIViewController {

    var bookId: String?
    
    @IBOutlet weak var bookImage: UIImageView!
    @IBOutlet weak var bookTitle: UILabel!
    @IBOutlet weak var bookSubtitle: UILabel!
    @IBOutlet weak var bookAuthors: UILabel!
    @IBOutlet weak var numberOfPages: UILabel!
    @IBOutlet weak var bookDescription: UILabel!
    
    var bookInfo: [String: String] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setBookInfo()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }    
    
    func setBookInfo(){
        
        let url = "https://www.googleapis.com/books/v1/volumes/\(self.bookId!)"
        
        URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
        
            
            if (error != nil) {
                print(error?.localizedDescription)
            } else {
                
                let json = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: AnyObject]
                
                if let volume = json?["volumeInfo"] as? [String: AnyObject] {
                    
                    if let image = volume["imageLinks"] as? [String: String] {
                        
                        self.bookImage.imageFromUrl(urlString: image["thumbnail"]!)
                    }
                    
                    self.bookInfo["title"] = volume["title"] as? String
                    
                    if let subtitle = volume["subtitle"] as? String {
                        self.bookInfo["subtitle"] = subtitle
                    }
                    
                    if let authors = volume["authors"] as? [String] {
                        self.bookInfo["authors"] = ""
                        for author in authors {
                            if (self.bookInfo["authors"] != ""){
                                self.bookInfo["authors"]?.append(", ")
                            }
                            self.bookInfo["authors"]?.append(author)
                        }
                    }
                    
                    if let num = volume["pageCount"] as? String {
                        self.bookInfo["numOfPages"] = num
                    }
                    
                    if let desc = volume["description"] as? String {
                        self.bookInfo["description"] = desc.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
                    }
                    
                }
                
                
                self.bookTitle.text = self.bookInfo["title"]
                self.bookSubtitle.text = self.bookInfo["subtitle"]
                self.bookAuthors.text = self.bookInfo["authors"]
                self.bookDescription.text = self.bookInfo["description"]
                self.numberOfPages.text = self.bookInfo["numOfPages"]
            }
            
        }.resume()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


