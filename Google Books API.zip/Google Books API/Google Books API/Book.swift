//
//  Book.swift
//  Google Books API
//
//  Created by User on 10/10/16.
//  Copyright © 2016 User. All rights reserved.
//

import UIKit

class Book: NSObject {
    var id: String?
    var title: String?
    var author: String?
    var imageURL: String?

}
