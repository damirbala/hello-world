//
//  ViewController.swift
//  Converter
//
//  Created by Damir on 14.09.16.
//  Copyright © 2016 Damir. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var text1: UITextField!
    @IBOutlet weak var result: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func toBin(sender: AnyObject) {
        
        text1.text = "To bin"
    }

    @IBAction func toDec(sender: AnyObject) {
        text1.text = "To dec"
    }
    
}

