//
//  GameViewController.swift
//  Crazy Mathematician
//
//  Created by Damir Mukametkarim on 04.10.16.
//  Copyright © 2016 Damir Mukametkarim. All rights reserved.
//

import UIKit

protocol GameViewControllerDelegate {
    func gameScoreAndName(score: Int, name: String)
   
   }

class GameViewController: UIViewController {

    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var bottomView: UIView!
    
    @IBOutlet weak var answerTextField: UITextField!
    
    @IBOutlet weak var timerLabel: UILabel!
    
    @IBOutlet weak var scoreLabel: UILabel!
    
    var tempField : UITextField!
    
    var delegate: GameViewControllerDelegate?
    var timer = Timer()
    var timer1 = Timer()
    
    var x = 0
    var y = 0
    var gameTime = 20
    var score = 0
    var doubleScored = 2
    var acc = 0.4
    var opt : UInt32 = 0
    var val1 = 0
    var val2 = 0
    var level : String! = ""
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        
      // _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(GameViewController.createAlert), userInfo: nil, repeats: false)

        if let def = level {
        if(def == "EASY"){
            
            self.opt = 9
            self.val1 = 3
            self.val2 = 1
            self.Settings()
            
        }else if(def == "MEDIUM"){
            self.opt = 99
            self.val1 = 2
            self.val2 = 2
            self.Settings()
        }else if(def == "HARD"){
            self.opt = 999
            self.val1 = 1
            self.val2 = 3
            self.Settings()
        }
        }
        else{
            print ("error")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be	ecreated.
    }
    
  
    
 
    
    func Settings(){
        self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(GameViewController.updateTimer), userInfo: nil, repeats: true)
        
        self.createTimer(interval: self.acc)
        
        self.timerLabel.text = "0:\(gameTime)"
        newQuestion()
    }
    
  
    
    func newQuestion(){
        
        
        
        self.x = Int(arc4random_uniform(opt) + 1)
        
        self.y = Int(arc4random_uniform(opt) + 1)
        
        self.questionLabel.text = "\(self.x)X\(self.y)="
        
        self.questionLabel.center.y = 50
        
        
        
    }
    
    func moveQuestionLabel(){
        if(self.questionLabel.center.y >= self.bottomView.center.y){
            score = score - val1
            doubleScored -= 1
        
            if(acc<0.8){
            acc += 0.1
                timer1.invalidate()
                createTimer(interval: acc)

            }
            
            scoreLabel.text = "Your score: \(score)"
            newQuestion()
        }
        UIView.animate(withDuration: acc) {
            self.questionLabel.center.y += 10
        }
    }
    
    func updateTimer(){
       
        gameTime = gameTime - 1
        self.timerLabel.text = "0:\(gameTime)"
    
        if(gameTime==0){
            timer.invalidate()
            gameOver()
        }
    }

    
    func gameOver(){
        
        
        
        
        
       let alert = UIAlertController(title: "Game Over", message: "Your score is \(score)",preferredStyle:.alert)
        
        alert.addTextField(configurationHandler: {(textField : UITextField!) -> Void in
            textField.placeholder = "Write your name"
            
        })

        
                alert.addAction(UIAlertAction(title: "Ok",style: .default, handler: {(action) in
            
                    let userField = alert.textFields![0] as UITextField
                    
                     self.delegate?.gameScoreAndName(score: self.score, name: userField.text!)
                    self.dismiss(animated: true, completion: nil)
                    
        }))
        
        

        present(alert, animated: true , completion: nil)
        
        timer1.invalidate()

    }
    
    func createTimer(interval: TimeInterval){
        
       timer1 = Timer.scheduledTimer(timeInterval: acc, target: self, selector: #selector(GameViewController.moveQuestionLabel), userInfo: nil, repeats: true)

    }
    
    @IBAction func submitButtonPressed(_ sender: UIButton) {
        
        let res = Int(self.answerTextField.text!)
        
        if(res==x*y){
            
            score = score + val2
            scoreLabel.text = "Your score: \(score)"
            newQuestion()
            
        }

        if(score==doubleScored){
            
            doubleScored += 2
            
            if(acc > 0.2){
            acc -= 0.1
                timer1.invalidate()
                createTimer(interval: acc)
            }
            
          
        }
        
        self.answerTextField.text = ""
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

 

}

