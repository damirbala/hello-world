//
//  ViewController.swift
//  Crazy Mathematician
//
//  Created by Damir Mukametkarim on 04.10.16.
//  Copyright © 2016 Damir Mukametkarim. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var userLabel: UILabel!
   
    var bestScore = 0
    var bestName: String = "???"
    var justScore = 0
    var justName: String = "???"
    var option = 0
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.bestScore = UserDefaults.standard.integer(forKey: "bestScore")
       
        if  UserDefaults.standard.string(forKey: "bestName") != nil {
            self.bestName = UserDefaults.standard.string(forKey: "bestName")!

        }
        else{
            self.bestName = "???"
        }
        
    
        self.scoreLabel.text = "\(bestScore)"
        self.userLabel.text = "\(bestName)"
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func playButtonPressed(_ sender: UIButton) {
       
      
       self.performSegue(withIdentifier: "toGameVC", sender: sender)
        
       
        
    }
    
  

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
    
        
        if (segue.destination.isKind(of: GameViewController.self)){
            
            let gameVC = segue.destination as! GameViewController
            gameVC.delegate = self
            gameVC.level = (sender as! UIButton?)?.titleLabel?.text!
        }else if(segue.destination.isKind(of: ResultsViewController.self)){
         
            let ResultsVC = segue.destination as! ResultsViewController
            
          
            ResultsVC.justN = UserDefaults.standard.string(forKey: "justName")!
            
            
            ResultsVC.justS = UserDefaults.standard.integer(forKey: "justScore")
            
            
            
            
            
        }
    }
    
    @IBAction func seeButtonPressed(_ sender: UIButton) {
        self.performSegue(withIdentifier: "toResultsVC", sender: sender)
   
    }
    
    @IBAction func easyButtonPressed(_ sender: UIButton) {
        playButtonPressed(sender)
    }
    
    @IBAction func mediumButtonPressed(_ sender: UIButton) {
        playButtonPressed(sender)
    }
    
    @IBAction func hardButtonPressed(_ sender: UIButton) {
        playButtonPressed(sender)
    }
}

extension ViewController: GameViewControllerDelegate {
    func gameScoreAndName(score: Int, name: String) {
        
        print ("proverka")
        
        if (score>bestScore){
            bestScore = score
            bestName = name
            UserDefaults.standard.set(bestScore, forKey: "bestScore")
            UserDefaults.standard.set(bestName, forKey: "bestName")
        }
     
        self.scoreLabel.text = "\(bestScore)"
        self.userLabel.text = "\(bestName)"
        
        justScore = score
        justName = name
        
        UserDefaults.standard.set(justScore, forKey: "justScore")
        UserDefaults.standard.set(justName, forKey: "justName")
        
    }
    
  }
