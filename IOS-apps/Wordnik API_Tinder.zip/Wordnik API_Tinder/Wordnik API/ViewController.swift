//
//  ViewController.swift
//  Wordnik API
//
//  Created by Damir on 30.10.16.
//  Copyright © 2016 mdt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var viewPlace: UIView!
    
    @IBOutlet weak var sozLabel: UILabel!
    var words : [String] = []
    var defs: [String] = []
    var defi: String!
    var k: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.searchBar.delegate = self
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func searchSynonyms(text: String) {
        let text = text.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!.lowercased()
        
        let url = "http://api.wordnik.com:80/v4/word.json/\(text)/relatedWords?useCanonical=false&relationshipTypes=synonym&limitPerRelationshipType=10&api_key=a2a73e7b926c924fad7001ca3111acd55af2ffabf50eb4ae5"
        
        print(url)
        
        URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
            if error != nil {
                print(error?.localizedDescription)
            }else {
               // print(String(data: data!, encoding: String.Encoding.utf8))
                
                let json = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [[String: AnyObject]]
                
                if json.count > 0 {
                    let item = json[0]

                    if let words = item["words"] as? [String] {
                        
                        self.defs = []
                        
                        
                        for word in words {
                            
                            if self.k != 0 {
                            while(self.defs[self.k] == ""){
                                
                            
                                if self.defs[self.k-1] != "" {
                                    let url1 = "http://api.wordnik.com:80/v4/word.json/\(word)/definitions?limit=10&includeRelated=true&sourceDictionaries=century&useCanonical=false&includeTags=false&api_key=a2a73e7b926c924fad7001ca3111acd55af2ffabf50eb4ae5"
                                    
                                    URLSession.shared.dataTask(with: URL(string: url1)!) { (data, response, error) in
                                        if error != nil {
                                            print(error?.localizedDescription)
                                        }else {
                                            //print(String(data: data!, encoding: String.Encoding.utf8))
                                            
                                            let json1 = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [[String: AnyObject]]
                                            
                                            if json1.count > 0 {
                                                let item1 = json1[0]
                                                
                                                
                                                self.defs.append((item1["text"] as! String?)!)
                                                
                                                
                                                if words.last == word {
                                                    DispatchQueue.main.async {
                                                        
                                                        for opr in self.defs {
                                                            
                                                            print("def is \(opr)")
                                                            
                                                        }
                                                        
                                                        print("count is \(self.defs.count)")
                                                        self.displayWords(words: words)
                                                        
                                                    }
                                                }
                                                
                                                
                                                
                                            }
                                        }
                                        }.resume()

                                                          }
                                                          self.k+=1
                            }
                            } else {
                                let url1 = "http://api.wordnik.com:80/v4/word.json/\(word)/definitions?limit=10&includeRelated=true&sourceDictionaries=century&useCanonical=false&includeTags=false&api_key=a2a73e7b926c924fad7001ca3111acd55af2ffabf50eb4ae5"
                                
                                URLSession.shared.dataTask(with: URL(string: url1)!) { (data, response, error) in
                                    if error != nil {
                                        print(error?.localizedDescription)
                                    }else {
                                        //print(String(data: data!, encoding: String.Encoding.utf8))
                                        
                                        let json1 = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [[String: AnyObject]]
                                        
                                        if json1.count > 0 {
                                            let item1 = json1[0]
                                            
                                            
                                            self.defs.append((item1["text"] as! String?)!)
                                            
                                            
                                            if words.last == word {
                                                DispatchQueue.main.async {
                                                    
                                                    for opr in self.defs {
                                                        
                                                        print("def is \(opr)")
                                                        
                                                    }
                                                    
                                                    print("count is \(self.defs.count)")
                                                    self.displayWords(words: words)
                                                    
                                                }
                                            }
                                            
                                            
                                            
                                        }
                                    }
                                    }.resume()
                                
                            }

                            
                            
                            print("Word is \(word)")
                        }
                        
              
                        
                        
                 
                    }
                }
            }
        }.resume()
    }
    
    func displayWords(words: [String]) {
        self.words = words
        
        if words.count > 0 {
            
            let singleWordVC = self.storyboard?.instantiateViewController(withIdentifier: "SingleWordVC")
            as! SingleWordViewController
            
            singleWordVC.word = words[0]
            singleWordVC.id = 0
            singleWordVC.counter = words.count
            singleWordVC.pos = 0
            singleWordVC.delegate = self
            singleWordVC.def = defs[0]
            
            
            let pageVC = UIPageViewController()
            
            pageVC.setViewControllers([singleWordVC], direction: .forward, animated: true, completion: nil)
            pageVC.view.frame = self.viewPlace.frame
            
            self.addChildViewController(pageVC)
            self.view.addSubview(pageVC.view)
            pageVC.didMove(toParentViewController: self)
            
            pageVC.dataSource = self
            
        }
    }
    
    


}


extension ViewController : UIPageViewControllerDataSource {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        let index = (viewController as! SingleWordViewController).id - 1
        
        if index < 0 {
            return nil
        }
        
        let singleWordVC = self.storyboard?.instantiateViewController(withIdentifier: "SingleWordVC")
            as! SingleWordViewController
        
        singleWordVC.word = words[index]
        singleWordVC.id = index
        singleWordVC.counter = words.count
        singleWordVC.pos = index
        singleWordVC.delegate = self
        singleWordVC.def = defs[index]
     
       

        return singleWordVC
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let index = (viewController as! SingleWordViewController).id + 1
        
        if index >= words.count {
            return nil
        }
        
        let singleWordVC = self.storyboard?.instantiateViewController(withIdentifier: "SingleWordVC")
            as! SingleWordViewController
        
        singleWordVC.word = words[index]
        singleWordVC.id = index
        singleWordVC.counter = words.count
        singleWordVC.pos = index
        singleWordVC.delegate = self
        singleWordVC.def = defs[index]
      
      
        
        

        return singleWordVC

    }
    
}

extension ViewController : UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let text = searchBar.text!
        self.searchSynonyms(text: text)
        searchBar.text = ""
    }
    
    
    
}

extension ViewController: SingleWordViewControllerDelegate {
    
    func sendWord(word: String) {
        
        if word != "" {
        self.searchSynonyms(text: word)

        }
    }
    
}



