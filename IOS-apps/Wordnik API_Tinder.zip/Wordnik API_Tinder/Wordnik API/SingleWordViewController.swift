//
//  SingleWordViewController.swift
//  Wordnik API
//
//  Created by Damir on 30.10.16.
//  Copyright © 2016 mdt. All rights reserved.
//

import UIKit

protocol SingleWordViewControllerDelegate   {
    
    func sendWord(word: String)
    
}

class SingleWordViewController: UIViewController {
    
    var panGestureRecognizer: UIPanGestureRecognizer!
    var originPoint: CGPoint!
    var overlayView: OverlayView!
    var information: UILabel!
    var xFromCenter: Float!
    var yFromCenter: Float!


    @IBOutlet weak var wrapperView: UIView!
    @IBOutlet weak var wLabel: UILabel!
    @IBOutlet weak var wordLabel: UILabel!
    var showingLabel = true
    
    @IBOutlet weak var dots: UIPageControl!
    var wordik: UILabel!
    var definition: UILabel!
    
    var delegate: SingleWordViewControllerDelegate?
    var word: String!
    var def: String!
    var id: Int!
    var counter: Int!
    var pos: Int!
    var cou: Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        wordik = UILabel(frame: CGRectFromString("{{0,0},{271,238}}"))
        definition = UILabel(frame: CGRectFromString("{{0,0},{271,238)}}"))
        

        wordik.backgroundColor = UIColor.blue
        wordik.textColor = UIColor.white
        wordik.text = word
        wordik.textAlignment = NSTextAlignment.center
     
        
     
        definition.backgroundColor = UIColor.blue
        definition.textColor = UIColor.white
        definition.text = def
        definition.textAlignment = NSTextAlignment.center
                
     
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(self.tapped))
        singleTap.numberOfTapsRequired = 1
        
        
        
        self.wrapperView.addGestureRecognizer(singleTap)
        self.wrapperView.isUserInteractionEnabled = true
        
        if(self.showingLabel){
            self.wrapperView.addSubview(self.wordik)
        }else {
            self.wrapperView.addSubview(self.definition)
            
        }
        self.view.addSubview(self.wrapperView)
        
   
      
        dots.numberOfPages = counter
        dots.currentPage = pos
        
        
        panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(DraggableView.beingDragged(_:)))
        
        self.wrapperView.addGestureRecognizer(panGestureRecognizer)

        overlayView = OverlayView(frame: CGRect(x: self.wrapperView.frame.size.width/2-100, y: 0, width: 271, height: 278))
        overlayView.alpha = 0
        self.wrapperView.addSubview(overlayView)
        
        
        xFromCenter = 0
        yFromCenter = 0

   
        // Do any additional setup after loading the view.
    }

    func beingDragged(_ gestureRecognizer: UIPanGestureRecognizer) -> Void {
        xFromCenter = Float(gestureRecognizer.translation(in: self.wrapperView).x)
        yFromCenter = Float(gestureRecognizer.translation(in: self.wrapperView).y)
        
        switch gestureRecognizer.state {
        case UIGestureRecognizerState.began:
            self.originPoint = self.wrapperView.center
        case UIGestureRecognizerState.changed:
            let rotationStrength: Float = min(xFromCenter/ROTATION_STRENGTH, ROTATION_MAX)
            let rotationAngle = ROTATION_ANGLE * rotationStrength
            let scale = max(1 - fabsf(rotationStrength) / SCALE_STRENGTH, SCALE_MAX)
            
            self.wrapperView.center = CGPoint(x: self.originPoint.x + CGFloat(xFromCenter), y: self.originPoint.y + CGFloat(yFromCenter))
            
            let transform = CGAffineTransform(rotationAngle: CGFloat(rotationAngle))
            let scaleTransform = transform.scaledBy(x: CGFloat(scale), y: CGFloat(scale))
            self.wrapperView.transform = scaleTransform
            self.updateOverlay(CGFloat(xFromCenter))
        case UIGestureRecognizerState.ended:
            self.afterSwipeAction()
        case UIGestureRecognizerState.possible:
            fallthrough
        case UIGestureRecognizerState.cancelled:
            fallthrough
        case UIGestureRecognizerState.failed:
            fallthrough
        default:
            break
        }
    }
    
    func updateOverlay(_ distance: CGFloat) -> Void {
        if distance > 0 {
            overlayView.setMode(GGOverlayViewMode.ggOverlayViewModeRight)
        } else {
            overlayView.setMode(GGOverlayViewMode.ggOverlayViewModeLeft)
        }
        overlayView.alpha = CGFloat(min(fabsf(Float(distance))/100, 0.4))
    }
    
    func afterSwipeAction() -> Void {
        let floatXFromCenter = Float(xFromCenter)
        if floatXFromCenter > ACTION_MARGIN {
            self.rightAction()
        } else if floatXFromCenter < -ACTION_MARGIN {
            self.leftAction()
        } else {
            UIView.animate(withDuration: 0.3, animations: {() -> Void in
                self.wrapperView.center = self.originPoint
                self.wrapperView.transform = CGAffineTransform(rotationAngle: 0)
                self.overlayView.alpha = 0
            })
        }
    }
    
    func rightAction() -> Void {
        let finishPoint: CGPoint = CGPoint(x: 500, y: 2 * CGFloat(yFromCenter) + self.originPoint.y)
        UIView.animate(withDuration: 0.3,
                       animations: {
                        self.wrapperView.center = finishPoint
            }, completion: {
                (value: Bool) in
                self.wrapperView.removeFromSuperview()
        })
        cardSwipedRight(self)
    }
    
    func leftAction() -> Void {
        let finishPoint: CGPoint = CGPoint(x: -500, y: 2 * CGFloat(yFromCenter) + self.originPoint.y)
        UIView.animate(withDuration: 0.3,
                       animations: {
                        self.center = finishPoint
            }, completion: {
                (value: Bool) in
                self.removeFromSuperview()
        })
        cardSwipedLeft(self)
    }
    
    func rightClickAction() -> Void {
        let finishPoint = CGPoint(x: 600, y: self.wrapperView.center.y)
        UIView.animate(withDuration: 0.3,
                       animations: {
                        self.center = finishPoint
                        self.transform = CGAffineTransform(rotationAngle: 1)
            }, completion: {
                (value: Bool) in
                self.removeFromSuperview()
        })
      cardSwipedRight(self)
    }
    
    func leftClickAction() -> Void {
        let finishPoint: CGPoint = CGPoint(x: -600, y: self.wrapperView.center.y)
        UIView.animate(withDuration: 0.3,
                       animations: {
                        self.center = finishPoint
                        self.transform = CGAffineTransform(rotationAngle: 1)
            }, completion: {
                (value: Bool) in
                self.removeFromSuperview()
        })
        cardSwipedLeft(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func tapped() {
        if showingLabel {
            
            UIView.transition(from: wordik, to: definition, duration: 1, options: UIViewAnimationOptions.transitionFlipFromRight, completion: nil)
            showingLabel = false

        }else {
            UIView.transition(from: definition, to: wordik, duration: 1, options: UIViewAnimationOptions.transitionFlipFromLeft, completion: nil)
            showingLabel = true

        }
    }
    
    @IBAction func seeButtonPressed(_ sender: UIButton) {
      
        self.delegate?.sendWord(word: word)
        
    }
    
    @IBAction func dontknowButtonPressed(_ sender: UIButton) {
        if loadedCards.count <= 0 {
            return
        }
        var dragView: DraggableView = loadedCards[0]
        dragView.overlayView.setMode(GGOverlayViewMode.ggOverlayViewModeRight)
        UIView.animate(withDuration: 0.2, animations: {
            () -> Void in
            dragView.overlayView.alpha = 1
        })
        dragView.rightClickAction()

    }
    
    @IBAction func knowButtonPressed(_ sender: UIButton) {
        if loadedCards.count <= 0 {
            return
        }
        var dragView: DraggableView = loadedCards[0]
        dragView.overlayView.setMode(GGOverlayViewMode.ggOverlayViewModeLeft)
        UIView.animate(withDuration: 0.2, animations: {
            () -> Void in
            dragView.overlayView.alpha = 1
        })
        dragView.leftClickAction()
    }

    }

