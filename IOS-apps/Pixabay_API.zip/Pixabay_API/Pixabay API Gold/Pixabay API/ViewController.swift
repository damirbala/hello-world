//
//  ViewController.swift
//  Pixabay API
//
//  Created by Rustem on 09.12.16.
//  Copyright © 2016 Tursynkan Rustem. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var pictureURLs : [String] = []
    var videoURLs : [String] = []
    var tags : [String] = []
    var oneVideo = "test"
    var playerViewContrloller = AVPlayerViewController()
    var playerView = AVPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        collectionView.delegate = self
        collectionView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func getPictures(query: String) {
        let query = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let url = "https://pixabay.com/api/videos/?key=3588547-45622bf326677af0e44312a7d&q=\(query)"
        print(url )
        URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
            if(error != nil) {
                print(error?.localizedDescription as Any)
            } else {
                let json = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject]
                if let hits = json["hits"] as? [[String:AnyObject]] {
                    self.pictureURLs = []
                    self.videoURLs = []
                    
                    for picture in hits {
                        if let pictureId = picture["picture_id"] as? String {
                             self.pictureURLs.append("https://i.vimeocdn.com/video/\(pictureId)_640x360.jpg")
                        }
                    }
                    
                    for video in hits {
                        if let anyVideo = video["videos"] as? [String:AnyObject] {
                            if let someVideo = anyVideo["large"] as? [String:AnyObject] {
                                if let oneVideo = someVideo["url"] as? String {
                                    self.videoURLs.append(oneVideo)
                                }
                            }
                        }
                    }
                    
                    for tag in hits {
                        if let oneTag = tag["tags"] as? String {
                            self.tags.append(oneTag)
                            
                        }
                    }
                    DispatchQueue.main.async {
                        self.collectionView.reloadData()
                    }
                }
            }
        }.resume()
    }
}

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1;
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.pictureURLs.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:  "Cell", for: indexPath) as! PhotoCollectionViewCell
        cell.imageView.imageFromURL(urlString: self.pictureURLs[indexPath.row])
        cell.tagLabel.text = tags[indexPath.row]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.oneVideo = videoURLs[indexPath.row]
        let videoURL = NSURL(string: self.oneVideo)
        playerView = AVPlayer (url: videoURL as! URL)
        playerViewContrloller.player = playerView
        present(playerViewContrloller, animated: true) {
            self.playerViewContrloller.player?.play()
        }
    }
}

extension ViewController : UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let text = searchBar.text
        if(text != nil) {
            self.getPictures(query: text!)
        }
    }
}

extension UIImageView {
    public func imageFromURL(urlString : String) {
        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with:  url, completionHandler: { (data, response, error) in
                if (error != nil) {
                    print(error?.localizedDescription as Any)
                } else {
                    if let image = UIImage(data: data!) {
                        DispatchQueue.main.async {
                            self.image = image
                        }
                    }
                }
            }).resume()
        }
    }
}
