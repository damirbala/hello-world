//
//  PhotoCollectionViewCell.swift
//  Pixabay API
//
//  Created by Rustem on 09.12.16.
//  Copyright © 2016 Tursynkan Rustem. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var tagLabel: UILabel!
    
}
