//
//  ImageViewController.swift
//  Pixabay API
//
//  Created by Данияр Беккужин on 24.10.16.
//  Copyright © 2016 Bekkuzhin Daniyar. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation


class ImageViewController: UIViewController {

    var tags = ""
    var photo = ""
    var video = ""
    
    var playerViewContrloller = AVPlayerViewController()
    var playerView = AVPlayer()
    
    @IBOutlet weak var exLabel: UILabel!
    
    @IBOutlet weak var webView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        exLabel.text = self.tags
        /*
        webView.loadHTMLString("<iframe width = \" \(self.webView.frame.width) \" height = \" \(self.webView.frame.height) \" src = \"\(self.video)\"> </iframe>", baseURL: nil)
        */
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let videoURL = NSURL(fileURLWithPath: self.video)
        playerView = AVPlayer (url: videoURL as URL)
        
        playerViewContrloller.player = playerView
        
        present(playerViewContrloller, animated: true) { 
            self.playerViewContrloller.player?.play()
        }
    }

}
