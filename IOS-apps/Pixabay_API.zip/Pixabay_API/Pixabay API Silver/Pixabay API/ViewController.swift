//
//  ViewController.swift
//  Pixabay API
//
//  Created by Данияр Беккужин on 18.10.16.
//  Copyright © 2016 Bekkuzhin Daniyar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var pictureURLs : [String] = []
    var HDpictureURLs : [String] = []
    var tags : [String] = []
    
    var oneTag = "test"
    var onePhoto = "test"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        collectionView.delegate = self
        collectionView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func getPictures(query: String) {
        let query = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let url = "https://pixabay.com/api/?key=3588547-45622bf326677af0e44312a7d&response_group=high_resolution&q=\(query)"
        URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
            if(error != nil) {
                print(error?.localizedDescription as Any)
            } else {
                let json = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject]
                if let hits = json["hits"] as? [[String:AnyObject]] {
                    self.pictureURLs = []
                    
                    for picture in hits {
                        if let previewURL = picture["previewURL"] as? String {
                             self.pictureURLs.append(previewURL)
                        }
                    }
                    self.HDpictureURLs = []
                    
                    for picture in hits {
                        if let HDpreviewURL = picture["fullHDURL"] as? String {
                            self.HDpictureURLs.append(HDpreviewURL)
                        }
                    }
                    DispatchQueue.main.async {
                        self.collectionView.reloadData()
                    }
                }
                
            }
        }.resume()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toImageVC" {
            let imageVC: ImageViewController = segue.destination as! ImageViewController
            imageVC.photo = onePhoto
        }
    }
    
}

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1;
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.pictureURLs.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:  "Cell", for: indexPath) as! PhotoCollectionViewCell
        
        cell.imageView.imageFromURL(urlString: self.pictureURLs[indexPath.row])

        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let destination = storyboard.instantiateViewController(withIdentifier: "ImageVC") as! ImageViewController
        navigationController?.pushViewController(destination, animated: true)
        
        self.onePhoto = HDpictureURLs[indexPath.row]
        performSegue(withIdentifier: "toImageVC", sender: self)
    }

}

extension ViewController : UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let text = searchBar.text
        if(text != nil) {
            self.getPictures(query: text!)
        }
    }
}

extension UIImageView {
    
    public func imageFromURL(urlString : String) {
        
        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with:  url, completionHandler: { (data, response, error) in
                if (error != nil) {
                    print(error?.localizedDescription as Any)
                } else {
                    if let image = UIImage(data: data!) {
                        DispatchQueue.main.async {
                            self.image = image
                        }
                    }
                }
            }).resume()
        }
        
    }
    
}
