//
//  PhotoCollectionViewCell.swift
//  Pixabay API
//
//  Created by Данияр Беккужин on 23.10.16.
//  Copyright © 2016 Bekkuzhin Daniyar. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var tagLabel: UILabel!
    
}
