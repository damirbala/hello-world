//
//  SingleWordViewController.swift
//  Wordnik API
//
//  Created by Damir on 30.10.16.
//  Copyright © 2016 mdt. All rights reserved.
//

import UIKit

protocol SingleWordViewControllerDelegate   {
    
    func sendWord(word: String)
    
}

class SingleWordViewController: UIViewController {

    @IBOutlet weak var wrapperView: UIView!
    @IBOutlet weak var wLabel: UILabel!
    @IBOutlet weak var wordLabel: UILabel!
    var showingLabel = true
    
    @IBOutlet weak var dots: UIPageControl!
    var wordik: UILabel!
    var definition: UILabel!
    
    var delegate: SingleWordViewControllerDelegate?
    var word: String!
    var def: String!
    var id: Int!
    var counter: Int!
    var pos: Int!
    var cou: Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        wordik = UILabel(frame: CGRectFromString("{{0,0},{271,238}}"))
        definition = UILabel(frame: CGRectFromString("{{0,0},{271,238)}}"))
        

        wordik.backgroundColor = UIColor.blue
        wordik.textColor = UIColor.white
        wordik.text = word
        wordik.textAlignment = NSTextAlignment.center
     
        
     
        definition.backgroundColor = UIColor.blue
        definition.textColor = UIColor.white
        definition.text = def
        definition.textAlignment = NSTextAlignment.center
                
     
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(self.tapped))
        singleTap.numberOfTapsRequired = 1
        
        
        
        self.wrapperView.addGestureRecognizer(singleTap)
        self.wrapperView.isUserInteractionEnabled = true
        
        if(self.showingLabel){
            self.wrapperView.addSubview(self.wordik)
        }else {
            self.wrapperView.addSubview(self.definition)
            
        }
        self.view.addSubview(self.wrapperView)
        
   
      
        dots.numberOfPages = counter
        dots.currentPage = pos
        
   
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func tapped() {
        if showingLabel {
            
            UIView.transition(from: wordik, to: definition, duration: 1, options: UIViewAnimationOptions.transitionFlipFromRight, completion: nil)
            showingLabel = false

        }else {
            UIView.transition(from: definition, to: wordik, duration: 1, options: UIViewAnimationOptions.transitionFlipFromLeft, completion: nil)
            showingLabel = true

        }
    }
    
    @IBAction func seeButtonPressed(_ sender: UIButton) {
      
        self.delegate?.sendWord(word: word)
        
    }

}
