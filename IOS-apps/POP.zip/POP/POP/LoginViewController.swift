//
//  LoginViewController.swift
//  POP
//
//  Created by Damir on 31.12.16.
//  Copyright © 2016 mdt. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    var backendless = Backendless.sharedInstance()
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func LoginButtonPressed(_ sender: UIButton) {
    }

    @IBAction func noAccountButtonPressed(_ sender: UIButton) {
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    
        if segue.identifier == "toTabBarC"{
            
        }
        else if segue.identifier == "toRegVC"{
        
        }
    }
    
        
    //MARK - Backendless
    func registerUserAsync() {
        
        let user = BackendlessUser()
        user.email = "james.bond@mi6.co.uk"
        user.password = "iAmWatchingU"
        
        Backendless.sharedInstance().userService.registering(user,
                                            response: { (registeredUser : BackendlessUser!) -> () in
                                                print("User has been registered (ASYNC): \(registeredUser)")
            },
                                            error: { ( fault : Fault!) -> () in
                                                print("Server reported an error: \(fault)")
            } 
        ) 
    }
 

}
