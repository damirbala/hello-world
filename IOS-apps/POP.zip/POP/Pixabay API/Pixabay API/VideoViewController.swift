//
//  VideoViewController.swift
//  Pixabay API
//
//  Created by Rustem on 09.12.16.
//  Copyright © 2016 Tursynkan Rustem. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class VideoViewController: UIViewController {

    @IBOutlet weak var searchBar: UISearchBar!
  
    @IBOutlet weak var collectionView: UICollectionView!
    
     var videos: [Picture] = []
    
    let width = 181
    let height = 180

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        searchBar.delegate = self
        
        collectionView.delegate = self
        collectionView.dataSource = self

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
       
    }
    
    func playVideo(url: NSURL){
        
    
        
        let player = AVPlayer(url: url as URL)
        let playerController = AVPlayerViewController()
        
        playerController.player = player
        self.addChildViewController(playerController)
        self.view.addSubview(playerController.view)
        playerController.view.frame = self.view.frame
        
        player.play()
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func getVideos(query: String) {
        
        let query = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        
        let url = "https://pixabay.com/api/videos/?key=3587533-956a93c812d8ed195b7e6dbbd&q=\(query)"
        print(url)
        
        
        URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
            if error != nil {
                print(error?.localizedDescription)
            }else{
                let json = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String: AnyObject]
                
                if let hits = json["hits"] as? [[String: AnyObject]] {
                    self.videos = []
                    
                    
                    for picture in hits {
                        let pic = Picture()
                        
                        if let video = picture["videos"] as? [String: AnyObject] {
                            
                            
                            if let vidUrl = video["small"]  as? [String: AnyObject]{
                            
                                
                               
                                    pic.videoURL = vidUrl["url"] as! String?
                                
                            }
                        }
                        
                        self.videos.append(pic)
                    }
                    
                    for video in self.videos {
                    print("video links are", video.videoURL!)
                    }
                    
                
                    
                    DispatchQueue.main.async {
                        self.collectionView.reloadData()
                    }
                }
            }
            }.resume()
        
    }
    

}

extension VideoViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.videos.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! PhotoCollectionViewCell
        
        


        
        
        var link: String = self.videos[indexPath.row].videoURL!
        let Code:NSString = "<iframe width=\(width) height = \(height) src =\(link) frameborder = \(cell.webView.frame)></iframe>" as NSString

        if cell.webView.isLoading {
            cell.webView.loadHTMLString(Code as String, baseURL: nil)
            
        }
    
        
            return cell
        
        
        
    }
    
    
    

    
    
}

extension VideoViewController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        let text = searchBar.text
        
        if text != nil {
            self.getVideos(query: text!)
        }

        
        
        
    }
    
}



extension UIView {
    
    public func videoFromURL(urlString: String) {
        
        if let url = URL(string: urlString){
            URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
                if error != nil {
                    print(error?.localizedDescription)
                }
                else {
                    
                    DispatchQueue.main.async {
                        
                        let urlik = NSURL(string: urlString)
                        
                        let player = AVPlayer(url: urlik as URL!)
                        let playerController = AVPlayerViewController()
                        
                        playerController.player = player
                       
                        playerController.view.frame = self.frame
                        
                        //player.play()
                    }
                }
            }).resume()
        }
    }
}


