//
//  MainViewController.swift
//  Pixabay API
//
//  Created by Rustem on 09.12.16.
//  Copyright © 2016 Tursynkan Rustem. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
       
      
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func pictureButtonPressed(_ sender: UIButton) {
        self.performSegue(withIdentifier: "toPictureVC", sender: sender)
    }
    
    @IBAction func videoButtonPressed(_ sender: UIButton) {
        self.performSegue(withIdentifier: "toVideoVC", sender: sender)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination.isKind(of: ViewController.self){
            let pictureVC = segue.destination as! ViewController
        }else if(segue.destination.isKind(of: VideoViewController.self)){
            let videoVC = segue.destination as! VideoViewController
        }
    }

}
