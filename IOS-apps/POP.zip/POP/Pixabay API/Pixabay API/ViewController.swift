//
//  ViewController.swift
//  Pixabay API
//
//  Created by Rustem on 09.12.16.
//  Copyright © 2016 Tursynkan Rustem. All rights reserved.
//

import UIKit
import MediaPlayer

class ViewController: UIViewController {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var i  = 0
    var pictures: [Picture] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        searchBar.delegate = self
        
        collectionView.delegate = self
        collectionView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func getPictures(query: String) {
        
        let query = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!

        
        let url = "https://pixabay.com/api/?key=3587533-956a93c812d8ed195b7e6dbbd&q=\(query)&image_type=photo"
        print(url)
        
        URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
                if error != nil {
                print(error?.localizedDescription)
            }else {
                let json = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String: AnyObject]
                
                if let hits = json["hits"] as? [[String: AnyObject]] {
                    self.pictures = []
                    
                    
                    for picture in hits {
                        
                        let pic = Picture()
                        
                        
                        
                        if let previewURL = picture["previewURL"] as? String {
                            pic.imageURL = previewURL
                            pic.hashId  = previewURL
                        }
                        
                        
           
                        pic.tags = picture["tags"] as! String?
                        
                        self.pictures.append(pic)
                    }
                    
                    print("picture links are", self.pictures)
                    
                    DispatchQueue.main.async {
                        self.collectionView.reloadData()
                    }
                }
                
            }
        }.resume()
    }
    
   
        
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination.isKind(of: PictureViewController.self) {
            let pictureVC = segue.destination as! PictureViewController
         
            pictureVC.pictureHashId = sender as? String
        }
    }
    
    
    
    
}



extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.pictures.count
    }
    
 
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! PhotoCollectionViewCell
        
        
      
            
     
            
            cell.hashId = self.pictures[indexPath.row].hashId
            cell.imageView.imageFromUrl(urlString: self.pictures[indexPath.row].imageURL!)
            cell.tagsLabel.text = self.pictures[indexPath.row].tags!
           
        

       
        return cell
        
        
    }
    

    

        
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
       
       let cell = collectionView.cellForItem(at: indexPath) as? PhotoCollectionViewCell
       self.performSegue(withIdentifier: "toPictureVC", sender: cell?.hashId)
        
    }
    
  
    
}
    
   


extension ViewController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        let text = searchBar.text
       
        
        if text != nil {
            self.getPictures(query: text!)
        }

        
        
    }
    
}

extension UIImageView {
    
    public func imageFromUrl(urlString: String) {
        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
                if error != nil {
                    print(error?.localizedDescription)
                } else {
                    if let image = UIImage(data: data!) {
                        DispatchQueue.main.async {
                            self.image = image
                        }
                    }
                }
            }).resume()
        }
    }
    
}

