//
//  Picture.swift
//  Pixabay API
//
//  Created by Rustem on 09.12.16.
//  Copyright © 2016 Tursynkan Rustem. All rights reserved.
//

import UIKit

class Picture: NSObject {
    
    var imageURL : String?
    var tags: String?
    var hashId: String?
    var videoURL: String?
}
