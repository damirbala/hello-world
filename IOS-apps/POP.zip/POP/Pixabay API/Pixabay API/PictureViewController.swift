//
//  PictureViewController.swift
//  Pixabay API
//
//  Created by Rustem on 09.12.16.
//  Copyright © 2016 Tursynkan Rustem. All rights reserved.
//

import UIKit

class PictureViewController: UIViewController, UIScrollViewDelegate {

    var pictureHashId: String!
    
    var pictureRes: [String: String] = [:]

    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var someLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.scrollView.minimumZoomScale = 1.0
        
        self.scrollView.maximumZoomScale = 6.0
       
        self.scrollView.delegate = self
        
        setPictureResolution()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setPictureResolution() {
        
      

            self.imageView.imageFromUrl(urlString: pictureHashId)
    
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        
        return self.imageView
        
    }
}

